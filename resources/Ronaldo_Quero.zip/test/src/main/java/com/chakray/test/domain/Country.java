package com.chakray.test.domain;

import lombok.Data;

@Data
public class Country {
    private Long id;
    private String code;
    private String name;
}
