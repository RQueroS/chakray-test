package com.chakray.test.domain;

import java.util.UUID;

public record TokenPayload(UUID userId, String username) {

}
